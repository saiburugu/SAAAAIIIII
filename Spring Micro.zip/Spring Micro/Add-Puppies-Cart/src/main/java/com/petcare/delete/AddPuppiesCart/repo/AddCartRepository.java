package com.petcare.delete.AddPuppiesCart.repo;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.petcare.delete.AddPuppiesCart.model.CartPojo;

@Repository
public interface AddCartRepository extends MongoRepository<CartPojo, String>{

}
