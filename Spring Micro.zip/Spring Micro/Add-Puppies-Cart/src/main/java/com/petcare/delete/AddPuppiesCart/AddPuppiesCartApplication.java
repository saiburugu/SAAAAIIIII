package com.petcare.delete.AddPuppiesCart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@EnableDiscoveryClient
@SpringBootApplication
public class AddPuppiesCartApplication {

	public static void main(String[] args) {
		SpringApplication.run(AddPuppiesCartApplication.class, args);
	}

}
