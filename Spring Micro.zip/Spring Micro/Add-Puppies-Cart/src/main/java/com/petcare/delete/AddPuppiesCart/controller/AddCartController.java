package com.petcare.delete.AddPuppiesCart.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.petcare.delete.AddPuppiesCart.model.CartPojo;
import com.petcare.delete.AddPuppiesCart.repo.AddCartRepository;



@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class AddCartController {
	
	@Autowired
	private AddCartRepository cartrepo;
	
	
	 @PostMapping("/cart/add")
		public CartPojo addCart(@RequestBody CartPojo customer) {

		 CartPojo _customer = cartrepo.save(new CartPojo(customer.getUname(),customer.getCustomer()));
			return _customer;
		}
	 
	 @GetMapping("/cart/get")
	 public List<CartPojo> getAllPuppies() {
			System.out.println("Get all Puppies...");
			List<CartPojo> puppies = new ArrayList<>();
			cartrepo.findAll().forEach(puppies::add);
			return puppies;
			
//			@GetMapping("/pups")
//			public List<PuppyPojo> getAllPuppies() {
//				System.out.println("Get all Puppies...");
//				List<PuppyPojo> puppies = new ArrayList<>();
//				puprepo.findAll().forEach(puppies::add);
//				return puppies;
			
			}
	 
	 @DeleteMapping("/cart/{id}")
		public ResponseEntity<String> deleteCustomer(@PathVariable("id") String id) {
		 System.out.println(id);
			System.out.println("Delete Customer with ID = " + id + "...");

			cartrepo.deleteById(id);

			return new ResponseEntity<>("Puppy has been deleted!", HttpStatus.OK);
		}
}
