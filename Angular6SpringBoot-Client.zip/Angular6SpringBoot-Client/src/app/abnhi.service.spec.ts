import { TestBed, inject } from '@angular/core/testing';

import { AbnhiService } from './abnhi.service';

describe('AbnhiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AbnhiService]
    });
  });

  it('should be created', inject([AbnhiService], (service: AbnhiService) => {
    expect(service).toBeTruthy();
  }));
});
