import { Component, OnInit } from '@angular/core';
import { Cart } from 'src/app/cart';
import { Input} from '@angular/core';
import { CartService } from 'src/app/cart.service';
import { CartListComponent } from 'src/app/cart-list/cart-list.component';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  @Input() cart: Cart;
  cart2: Cart=new Cart();
  
  constructor(private customerService: CartService,private listComponent: CartListComponent) { }

  ngOnInit() {
    console.log(this.cart)
  }

  deleteCustomer(id:any) {
    console.log(this.cart)
    this.cart2.id=id;
    console.log(id);
    this.customerService.deleteCartPuppy(this.cart2.id)
      .subscribe(
        data => {
          console.log(data);
          this.listComponent.reloadData();
        },
        error => console.log(error));
  }
  readLocalStorageValue(key) {
    return localStorage.getItem(key);
}

}
