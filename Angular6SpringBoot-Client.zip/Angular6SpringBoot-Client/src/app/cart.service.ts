import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  private baseUrl = 'http://localhost:8888';
  private baseUrl2 = 'http://localhost:8888/addcart/api/cart/get';
  private baseUrl3 = 'http://localhost:8888/addcart/api/cart'
  
    constructor(private http: HttpClient) { }

    addToCart(cart: Object): Observable<Object> {
      console.log(cart);
      return this.http.post(`${this.baseUrl}` + `/addcart/api/cart/add`, cart);
    }

    deleteCartPuppy(id: number): Observable<any> {
      return this.http.delete(`${this.baseUrl3}/${id}`, { responseType: 'text' });
    }

    getCartList():any {
      return this.http.get(`${this.baseUrl2}`);
    }
}
